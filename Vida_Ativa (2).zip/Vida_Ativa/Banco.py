import sqlite3

conexao = sqlite3.connect('Banco.db')

cursor = conexao.cursor()

cursor.execute('CREATE TABLE IF NOT EXISTS treino('
               'id_treino INTEGER PRIMARY KEY AUTOINCREMENT,'
               'nome do aluno TEXT NOT NULL,'
               'genero TEXT,'
               'horario TEXT,'
               'dias na semana TEXT,'
               'observacoes TEXT,'
               'Professor TEXT)');

conexao.close()