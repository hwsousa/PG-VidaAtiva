from flask import Flask, render_template, g, request, redirect, session, url_for, flash
from tinydb import TinyDB, Query
import sqlite3

from Banco import cursor


def ligar_banco():
    banco = g._database = sqlite3.connect('Banco.db')
    cursor = banco.cursor()
    cursor.execute('PRAGMA foreign_keys = ON;')
    return banco
app = Flask(__name__)

app.secret_key = 'sua_chave_secreta'  # Necessário para usar flash messages


db = TinyDB('preCadastro.json')
User = Query()


@app.route('/')
def home():
    return render_template('login.html', titulo='Faça seu login de Administrador')

@app.route('/teladicas')
def telaDicas():
    return render_template('telaDicas.html', titulo='Tela Dicas')

@app.route('/login', methods=['POST'])
def login():
    nome = request.form['nome']
    senha = request.form['senha']
    user = db.get(User.nome == nome)

    if user and user['senha'] == senha:
        flash('Login bem-sucedido!', 'success')
        return redirect(url_for('Home'))
    else:
        flash('Nome ou senha incorretos.', 'danger')
        return redirect(url_for('home'))


@app.route('/cadTreino')
def cadtreino():
        banco = ligar_banco()
        cursor = banco.cursor()
        cursor.execute('SELECT nome FROM professores')
        professores = cursor.fetchall()
        return render_template("CadTreino.html", titulo = "Cadastro de Treino", professores=professores)

@app.route('/criartreino', methods=['POST'])
def criartreino():
    banco = ligar_banco()
    cursor = banco.cursor()
    nomeAluno = request.form['nome-aluno']
    sexo = request.form['sexo']
    hora = request.form['hora']
    dias = request.form['dias']
    observacoes = request.form['observacoes']
    cursor.execute('INSERT INTO treino'
                       '(nome,genero,horario,dias,observacoes)'
                       'VALUES (?,?,?,?,?);',
                       (nomeAluno,sexo,hora,dias,observacoes))
    banco.commit()
    return redirect('/listarTreino')

#Cadastro de Professores
@app.route('/cadProfessores')
def cadprofessores():
        return render_template('cadastroProfessor.html', titulo='Cadastro de Professores')


@app.route('/home')
def Home():
    return render_template("Home.html", titulo="Home")


@app.route('/EditarTreinos/<id>', methods = ['GET'])
def Editar_Treinos(id):
    banco = ligar_banco()
    cursor = banco.cursor()
    cursor.execute('SELECT * FROM treino WHERE id_treino=?', (id,))
    dado = cursor.fetchone()
    return render_template("Editar-Treinos.html", titulo="Editar Treinos", item=dado)

@app.route('/EditarProfessor/<id>', methods = ['GET'])
def Editar_Professor(id):
    banco = ligar_banco()
    cursor = banco.cursor()
    cursor.execute('SELECT * FROM professores WHERE ID=?',(id,))
    dado = cursor.fetchone()

    return render_template("Editar- Professor.html", titulo="Editar Professor", item = dado ,id = id)


@app.route('/criarprofessor', methods=['POST'])
def criar():
    nome = request.form['nome']
    genero = request.form.get('gender')
    telefone = request.form['telefone']
    diaSemana = request.form.get('diaSemana')
    banco = ligar_banco()
    cursor = banco.cursor()
    cursor.execute('INSERT INTO professores'
                   '(nome,genero,telefone,diaSemana)'
                   'VALUES (?,?,?,?);',
                   (nome,genero,telefone,diaSemana))
    banco.commit()
    return redirect('/listar')

@app.route('/listar')
def listagem():
    banco = ligar_banco()
    cursor = banco.cursor()
    cursor.execute('SELECT ID, nome,genero,telefone,diaSemana FROM professores;')
    professor = cursor.fetchall()
    return render_template('listagemProfessores.html', titulo='Listagem de Professores', Dados=professor)

@app.route('/listarTreino')
def listagemTreino():
    banco = ligar_banco()
    cursor = banco.cursor()
    cursor.execute('SELECT * FROM treino')
    treinos = cursor.fetchall()
    return render_template('listagemTreinos.html', titulo='Listagem de Treinos', DadosTreino = treinos)

@app.route('/alterar/<id>',methods =['PUT','POST'])
def alterar(id):
    nome = request.form['nome']
    genero = request.form['genero']
    telefone = request.form['telefone']
    DiasTrabalho = request.form['dias-trabalho']
    banco = ligar_banco()
    cursor = banco.cursor()
    cursor.execute('UPDATE professores SET nome=?, genero=?, telefone=?, diaSemana=?  WHERE ID=?',
                   (nome, genero, telefone, DiasTrabalho,id))
    banco.commit()
    return redirect('/listar')

@app.route('/alterarTreino/<id>',methods =['PUT','POST'])
def alterar_Treino(id):
    nome = request.form['nome']
    genero = request.form['genero']
    horario = request.form['horario']
    dias_trabalho = request.form['dias-trabalho']
    observacao = request.form['observacao']
    banco = ligar_banco()
    cursor = banco.cursor()
    cursor.execute('UPDATE treino SET nome=?, genero=?, horario=?, dias=?, observacoes=?  WHERE id_treino=?',
                   (nome, genero, horario, dias_trabalho,observacao,id))
    banco.commit()
    return redirect('/listarTreino')



@app.route('/excluir/<id>', methods = ['GET', 'DELETE'])
def excluir(id):
    banco = ligar_banco()
    cursor = banco.cursor()
    cursor.execute('DELETE FROM professores WHERE ID=?;',(id,))
    banco.commit()
    banco.rollback()
    return redirect('/listar')


@app.route('/excluirTreino/<id>', methods = ['GET', 'DELETE'])
def excluirTreino(id):
    banco = ligar_banco()
    cursor = banco.cursor()
    cursor.execute('DELETE FROM treino WHERE id_treino=?;',(id,))
    banco.commit()
    banco.rollback()
    return redirect('/listarTreino')


if __name__ == '__main__':
    app.run()
